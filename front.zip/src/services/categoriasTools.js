import axios from 'axios';

export const getCategoriasTools = async (token) => {
    try {
        const response = await axios.get('http://localhost:3000/api/categorias-herramientas', {
            headers: {
                'Authorization': `Bearer ${token}`
            },
    });
    return response.data;
    } catch (error) {
        console.error('Error al obtener las categorías de herramientas', error);
        return [];
    }
};