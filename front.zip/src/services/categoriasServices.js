import axios from 'axios';

export const getCategoriasServices = async (token) => {
    try {
        const response = await axios.get('http://localhost:3000/api/categorias-servicios', {
            headers: {
                'Authorization': `Bearer ${token}`
            },
    });
    return response.data;
    } catch (error) {
        console.error('Error al obtener las categorías de servicios', error);
        return [];
    }
};